Julien Rougerie
101067032
in this TAR, you will find:
-customer.c
-dispatchCenter.c
-display.c
-generator.c
-makefile
-simulator.c
-simulator.h
-stop.c
-taxi.c
-this readme
ISSUES:
DISPLAY
-The display will neither launch a taxi or display one. Most likely error is due to area 
where the display thread is created.
-There might be somthing wrong with the taxi function, but it will create taxis and attept to connect.
-Occasionally, after running things like ./customer, the program will seg fault on ./stop
- if the connection does not bind, wait a moment before trying again.
- the helper methods have not been used and have been deleted. If one were to look on Discord, 
you would find that others have been arriving at the same erros due to these helper functions, in a way to justify me not using them.

