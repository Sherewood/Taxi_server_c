Julien Rougerie
101067032
in this TAR, you will find:
-customer.c
-dispatchCenter.c
-display.c
-generator.c
-makefile
-simulator.c
-simulator.h
-stop.c
-taxi.c
-this readme
ISSUES:
-The display will not show anyhthing
-the send of taxi.c does not send back, which might be the source of the error.
Any spare print statment is not an error, rather it might be for helping
-The program will not create Taxis.
