#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#include "simulator.h"

#include "taxi.c"
#include "display.c"
#include "dispatchCenter.c"

int main() {
  DispatchCenter     ottawaDispatch;


  srand(time(NULL));
  ottawaDispatch.numTaxis = 0;
  ottawaDispatch.numRequests = 0;
  pthread_t t1, t2;

  for (int i=0; i<10; i++)
  {

  Taxi *TAXI;
  TAXI= malloc(sizeof(Taxi));
  ottawaDispatch.taxis[i]= TAXI;
  TAXI->plateNumber=0;
  int randum= rand()%6;
  TAXI->currentArea= AREA_NAMES[randum];
  TAXI->pickupArea=UNKNOWN_AREA;
  TAXI->dropoffArea=UNKNOWN_AREA;
  TAXI->x=randum;
  TAXI->y=randum;
  TAXI->status=AVAILABLE;
  ottawaDispatch.taxis[i]=TAXI;
  pid_t pid= fork();
// sets up the fork
  if(pid==0)
    {

    runTaxi(TAXI);
    ottawaDispatch.numTaxis+=1;

    return 0;

    }
  else{
    TAXI->pID=pid;
      }
  }
  pthread_create(&t1, NULL,handleIncomingRequests,&ottawaDispatch); //launches the databasd
  pthread_create(&t2, NULL ,showSimulation, &ottawaDispatch);
  pthread_join(t1, NULL);

  printf("Simulation complete.\n");
}
